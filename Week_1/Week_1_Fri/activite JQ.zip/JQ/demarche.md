ça tombe bien c'est vraiment l'anniv de 2 très bonnes amies !
Le titre apparait avec un bouton sur lequel il faut cliquer.
Puis ensuite, chaque "boite" apparait au clic et la dernière offre un nouveau fond !
Il faut aussi attendre 5 sec et une petite alert surprise apparait.